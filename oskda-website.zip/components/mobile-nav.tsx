"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Menu, ChevronDown } from "lucide-react"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

export function MobileNav() {
  const [open, setOpen] = useState(false)
  const [aboutOpen, setAboutOpen] = useState(false)
  const [workOpen, setWorkOpen] = useState(false)
  const [newsOpen, setNewsOpen] = useState(false)
  const [involvedOpen, setInvolvedOpen] = useState(false)

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" className="md:hidden" aria-label="Open Menu">
          <Menu className="h-6 w-6" />
        </Button>
      </SheetTrigger>
      <SheetContent side="left" className="w-[300px] sm:w-[400px]">
        <nav className="flex flex-col gap-4 mt-8">
          <Link href="/" className="text-lg font-bold" onClick={() => setOpen(false)}>
            OSKDA
          </Link>
          <Link href="/" className="text-sm font-medium" onClick={() => setOpen(false)}>
            Home
          </Link>

          <Collapsible open={aboutOpen} onOpenChange={setAboutOpen}>
            <CollapsibleTrigger className="flex items-center justify-between w-full text-sm font-medium">
              About
              <ChevronDown className={`h-4 w-4 transition-transform ${aboutOpen ? "transform rotate-180" : ""}`} />
            </CollapsibleTrigger>
            <CollapsibleContent className="pl-4 pt-2 space-y-2">
              <Link href="#mission" className="block text-sm py-1" onClick={() => setOpen(false)}>
                Mission
              </Link>
              <Link href="#history" className="block text-sm py-1" onClick={() => setOpen(false)}>
                Our History
              </Link>
              <Link href="#founder" className="block text-sm py-1" onClick={() => setOpen(false)}>
                Our Founder
              </Link>
              <Link href="#leadership" className="block text-sm py-1" onClick={() => setOpen(false)}>
                Leadership
              </Link>
            </CollapsibleContent>
          </Collapsible>

          <Collapsible open={workOpen} onOpenChange={setWorkOpen}>
            <CollapsibleTrigger className="flex items-center justify-between w-full text-sm font-medium">
              Our Work
              <ChevronDown className={`h-4 w-4 transition-transform ${workOpen ? "transform rotate-180" : ""}`} />
            </CollapsibleTrigger>
            <CollapsibleContent className="pl-4 pt-2 space-y-2">
              <Link href="#nutrition" className="block text-sm py-1" onClick={() => setOpen(false)}>
                Nutrition
              </Link>
              <Link href="#food-safety" className="block text-sm py-1" onClick={() => setOpen(false)}>
                Food Safety
              </Link>
              <Link href="#education" className="block text-sm py-1" onClick={() => setOpen(false)}>
                Education
              </Link>
              <Link href="#health" className="block text-sm py-1" onClick={() => setOpen(false)}>
                Health
              </Link>
            </CollapsibleContent>
          </Collapsible>

          <Collapsible open={newsOpen} onOpenChange={setNewsOpen}>
            <CollapsibleTrigger className="flex items-center justify-between w-full text-sm font-medium">
              News & Reports
              <ChevronDown className={`h-4 w-4 transition-transform ${newsOpen ? "transform rotate-180" : ""}`} />
            </CollapsibleTrigger>
            <CollapsibleContent className="pl-4 pt-2 space-y-2">
              <Link href="#latest-news" className="block text-sm py-1" onClick={() => setOpen(false)}>
                Latest News
              </Link>
              <Link href="#financial-report" className="block text-sm py-1" onClick={() => setOpen(false)}>
                Financial Report
              </Link>
              <Link href="#strategic-plan" className="block text-sm py-1" onClick={() => setOpen(false)}>
                Strategic Plan
              </Link>
            </CollapsibleContent>
          </Collapsible>

          <Collapsible open={involvedOpen} onOpenChange={setInvolvedOpen}>
            <CollapsibleTrigger className="flex items-center justify-between w-full text-sm font-medium">
              Get Involved
              <ChevronDown className={`h-4 w-4 transition-transform ${involvedOpen ? "transform rotate-180" : ""}`} />
            </CollapsibleTrigger>
            <CollapsibleContent className="pl-4 pt-2 space-y-2">
              <Link href="#donate" className="block text-sm py-1" onClick={() => setOpen(false)}>
                Donate
              </Link>
              <Link href="#contact" className="block text-sm py-1" onClick={() => setOpen(false)}>
                Contact Us
              </Link>
              <Link href="#work-with-us" className="block text-sm py-1" onClick={() => setOpen(false)}>
                Work With Us
              </Link>
              <Link href="#openings" className="block text-sm py-1" onClick={() => setOpen(false)}>
                Openings
              </Link>
            </CollapsibleContent>
          </Collapsible>

          <Link href="#blog" className="text-sm font-medium" onClick={() => setOpen(false)}>
            Blog
          </Link>
        </nav>
      </SheetContent>
    </Sheet>
  )
}
