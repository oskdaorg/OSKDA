import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { ChevronRight, Menu } from "lucide-react"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="sticky top-0 z-50 w-full border-b bg-white">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Link href="/" className="font-bold text-xl md:text-2xl">
              OSKDA
            </Link>
            <span className="hidden md:inline-block text-sm text-muted-foreground">
              Open Society for Keeping Dignity Active
            </span>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="#" className="text-sm font-medium hover:underline underline-offset-4">
              Home
            </Link>
            <div className="relative group">
              <Link href="#about" className="text-sm font-medium hover:underline underline-offset-4">
                About
              </Link>
              <div className="absolute left-0 top-full hidden group-hover:block bg-white border rounded-md shadow-md p-2 w-48 z-50">
                <Link href="#mission" className="block px-3 py-2 text-sm hover:bg-muted rounded-md">
                  Mission
                </Link>
                <Link href="#history" className="block px-3 py-2 text-sm hover:bg-muted rounded-md">
                  Our History
                </Link>
                <Link href="#founder" className="block px-3 py-2 text-sm hover:bg-muted rounded-md">
                  Our Founder
                </Link>
                <Link href="#leadership" className="block px-3 py-2 text-sm hover:bg-muted rounded-md">
                  Leadership
                </Link>
              </div>
            </div>
            <div className="relative group">
              <Link href="#work" className="text-sm font-medium hover:underline underline-offset-4">
                Our Work
              </Link>
              <div className="absolute left-0 top-full hidden group-hover:block bg-white border rounded-md shadow-md p-2 w-48 z-50">
                <Link href="#nutrition" className="block px-3 py-2 text-sm hover:bg-muted rounded-md">
                  Nutrition
                </Link>
                <Link href="#food-safety" className="block px-3 py-2 text-sm hover:bg-muted rounded-md">
                  Food Safety
                </Link>
                <Link href="#education" className="block px-3 py-2 text-sm hover:bg-muted rounded-md">
                  Education
                </Link>
                <Link href="#health" className="block px-3 py-2 text-sm hover:bg-muted rounded-md">
                  Health
                </Link>
              </div>
            </div>
            <div className="relative group">
              <Link href="#news" className="text-sm font-medium hover:underline underline-offset-4">
                News & Reports
              </Link>
              <div className="absolute left-0 top-full hidden group-hover:block bg-white border rounded-md shadow-md p-2 w-48 z-50">
                <Link href="#latest-news" className="block px-3 py-2 text-sm hover:bg-muted rounded-md">
                  Latest News
                </Link>
                <Link href="#financial-report" className="block px-3 py-2 text-sm hover:bg-muted rounded-md">
                  Financial Report
                </Link>
                <Link href="#strategic-plan" className="block px-3 py-2 text-sm hover:bg-muted rounded-md">
                  Strategic Plan
                </Link>
              </div>
            </div>
            <div className="relative group">
              <Link href="#involved" className="text-sm font-medium hover:underline underline-offset-4">
                Get Involved
              </Link>
              <div className="absolute left-0 top-full hidden group-hover:block bg-white border rounded-md shadow-md p-2 w-48 z-50">
                <Link href="#donate" className="block px-3 py-2 text-sm hover:bg-muted rounded-md">
                  Donate
                </Link>
                <Link href="#contact" className="block px-3 py-2 text-sm hover:bg-muted rounded-md">
                  Contact Us
                </Link>
                <Link href="#work-with-us" className="block px-3 py-2 text-sm hover:bg-muted rounded-md">
                  Work With Us
                </Link>
                <Link href="#openings" className="block px-3 py-2 text-sm hover:bg-muted rounded-md">
                  Openings
                </Link>
              </div>
            </div>
            <Link href="#blog" className="text-sm font-medium hover:underline underline-offset-4">
              Blog
            </Link>
          </nav>
          <div className="md:hidden">
            <MobileNav />
          </div>
        </div>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-r from-green-50 to-teal-50">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center space-y-4 text-center">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl">
                  Open Society for Keeping Dignity Active
                </h1>
                <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl">
                  For Public Health Initiatives. For Education. For Advocacy. For Social Change and for Action.
                </p>
              </div>
              <div className="space-x-4">
                <Button asChild>
                  <Link href="#involved">Get Involved</Link>
                </Button>
                <Button variant="outline" asChild>
                  <Link href="#about">Learn More</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        <section id="news" className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Latest News</h2>
                <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl">
                  Stay updated with our recent activities and initiatives
                </p>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
              <NewsCard
                date="April 5, 2025"
                location="Bujumbura"
                title="Ms. Martine Iradukunda's dedication as an operating room nurse"
                description="Ms. Martine Iradukunda's dedication as an operating room nurse is evident in her care for young patients."
                publishDate="April 27, 2025"
              />
              <NewsCard
                date="March 26, 2025"
                location="Bujumbura"
                title="Every child holds a universe of potential"
                description="Every child in this room holds a universe of potential, a future we must fiercely protect."
                publishDate="April 27, 2025"
              />
              <NewsCard
                date="March 14, 2025"
                location="Matana"
                title="Micheline: Educator and OSKDA member"
                description="We proudly present Micheline, an esteemed educator and dedicated member of OSKDA, whose work embodies our mission."
                publishDate="April 27, 2025"
              />
            </div>
            <div className="flex justify-center mt-8">
              <Button variant="outline" asChild>
                <Link href="#blog">
                  View All News <ChevronRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </section>

        <section id="work" className="w-full py-12 md:py-24 lg:py-32 bg-gray-50">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Our Work</h2>
                <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl">
                  Making a difference in communities through various initiatives
                </p>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-8">
              <WorkCard
                title="Nutrition"
                description="One of OSKDA's goal is to eradicate malnutrition for the wellbeing of all children and parents."
                image="/placeholder.svg?height=200&width=300"
              />
              <WorkCard
                title="Food Safety"
                description="Ensuring communities have access to safe and nutritious food sources."
                image="/placeholder.svg?height=200&width=300"
              />
              <WorkCard
                title="Education"
                description="Supporting educational initiatives to empower future generations."
                image="/placeholder.svg?height=200&width=300"
              />
              <WorkCard
                title="Health"
                description="Contributing to reducing child morbidity and mortality associated with acute malnutrition and malaria."
                image="/placeholder.svg?height=200&width=300"
              />
            </div>
          </div>
        </section>

        <section id="about" className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
              <div className="space-y-4">
                <div className="inline-block rounded-lg bg-gray-100 px-3 py-1 text-sm">Our Mission</div>
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                  Cultivating Ubuntu's Value
                </h2>
                <p className="text-gray-500 md:text-xl">
                  Our mission is to contribute to the awareness and the value of Ubuntu – dignity in a logic of building
                  a better world.
                </p>
              </div>
              <div className="space-y-4">
                <div className="inline-block rounded-lg bg-gray-100 px-3 py-1 text-sm">Our Objective</div>
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Advancing Human Dignity</h2>
                <p className="text-gray-500 md:text-xl">
                  Our objective is to promote human dignity in order to contribute to the well-being of the entire
                  community in general and the vulnerable in particular.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section id="batwa" className="w-full py-12 md:py-24 lg:py-32 bg-gray-50">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                  Supporting the Batwa Community
                </h2>
                <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl">
                  OSKDA members paying a visit to the Batwa Community from Rweza (Bujumbura) to enquire about their
                  situation.
                </p>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
              <div className="rounded-lg overflow-hidden">
                <Image
                  src="/placeholder.svg?height=400&width=600"
                  alt="Batwa Community"
                  width={600}
                  height={400}
                  className="w-full h-auto object-cover"
                />
                <div className="p-4 bg-white">
                  <p className="text-gray-500">
                    Batwa Women and their children look very unfortunate. They are hungry, they have no cloths, and
                    their parents are jobless. They live of donations. They need their dignity back.
                  </p>
                </div>
              </div>
              <div className="rounded-lg overflow-hidden">
                <Image
                  src="/placeholder.svg?height=400&width=600"
                  alt="Children of the Batwa Community"
                  width={600}
                  height={400}
                  className="w-full h-auto object-cover"
                />
                <div className="p-4 bg-white">
                  <p className="text-gray-500">Children of the Batwa Community receiving snacks during OSKDA's visit</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="contact" className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
              <div className="space-y-4">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Contact Us</h2>
                <p className="text-gray-500 md:text-xl">
                  Get in touch with us to learn more about our initiatives or how you can get involved.
                </p>
                <div className="space-y-2">
                  <div className="flex items-center">
                    <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center mr-4">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="h-6 w-6"
                      >
                        <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                      </svg>
                    </div>
                    <div>
                      <p className="text-sm font-medium">Phone</p>
                      <p className="text-gray-500">+1 (646) 712-2911</p>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center mr-4">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="h-6 w-6"
                      >
                        <rect x="2" y="4" width="20" height="16" rx="2"></rect>
                        <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"></path>
                      </svg>
                    </div>
                    <div>
                      <p className="text-sm font-medium">Email</p>
                      <p className="text-gray-500">Gordien.Ndizeye@oskda.org</p>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center mr-4">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="h-6 w-6"
                      >
                        <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"></path>
                        <circle cx="12" cy="10" r="3"></circle>
                      </svg>
                    </div>
                    <div>
                      <p className="text-sm font-medium">Address</p>
                      <p className="text-gray-500">Av de l'imprimerie No 57</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="space-y-4">
                <div className="grid gap-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label
                        htmlFor="first-name"
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        First name
                      </label>
                      <input
                        id="first-name"
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                        placeholder="Enter your first name"
                      />
                    </div>
                    <div className="space-y-2">
                      <label
                        htmlFor="last-name"
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        Last name
                      </label>
                      <input
                        id="last-name"
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                        placeholder="Enter your last name"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label
                      htmlFor="email"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Email
                    </label>
                    <input
                      id="email"
                      type="email"
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      placeholder="Enter your email"
                    />
                  </div>
                  <div className="space-y-2">
                    <label
                      htmlFor="message"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Message
                    </label>
                    <textarea
                      id="message"
                      className="flex min-h-[120px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      placeholder="Enter your message"
                    ></textarea>
                  </div>
                  <Button>Send Message</Button>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="w-full border-t py-6 md:py-0">
        <div className="container flex flex-col md:flex-row items-center justify-between gap-4 md:h-24 px-4 md:px-6">
          <p className="text-center text-sm leading-loose text-gray-500 md:text-left">
            © 2025 OSKDA. All rights reserved.
          </p>
          <div className="flex items-center gap-4">
            <Link href="#" className="text-sm font-medium hover:underline underline-offset-4">
              Privacy Policy
            </Link>
            <Link href="#" className="text-sm font-medium hover:underline underline-offset-4">
              Terms of Service
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}

function NewsCard({ date, location, title, description, publishDate }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="line-clamp-2">{title}</CardTitle>
        <CardDescription>
          On {date} at {location}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <p className="line-clamp-3 text-sm text-gray-500">{description}</p>
      </CardContent>
      <CardFooter className="flex justify-between">
        <p className="text-xs text-gray-500">on {publishDate}</p>
        <Button variant="ghost" size="sm" asChild>
          <Link href="#">read more</Link>
        </Button>
      </CardFooter>
    </Card>
  )
}

function WorkCard({ title, description, image }) {
  return (
    <div className="rounded-lg overflow-hidden border bg-white">
      <Image
        src={image || "/placeholder.svg"}
        alt={title}
        width={300}
        height={200}
        className="w-full h-48 object-cover"
      />
      <div className="p-4">
        <h3 className="font-bold text-lg mb-2">{title}</h3>
        <p className="text-sm text-gray-500">{description}</p>
        <Button variant="link" className="p-0 h-auto mt-2" asChild>
          <Link href="#">read more</Link>
        </Button>
      </div>
    </div>
  )
}

function MobileNav() {
  return (
    <div className="relative">
      <Button variant="ghost" size="icon" className="md:hidden" aria-label="Open Menu">
        <Menu className="h-6 w-6" />
      </Button>
    </div>
  )
}
